//
//  CustomCell.swift
//  LoginTest
//
//  Created by yam7611 on 10/4/16.
//  Copyright © 2016 yam7611. All rights reserved.
//

import UIKit
import Firebase

class CustomCell: UITableViewCell {

    var currentIndex:Int?
    let subtitleLabel = UILabel()
    let detailLabel = UILabel()
    let timestampLabel = UILabel()
    var myAccount = ""
    let messagePhoto :UIImageView = {
        let tempImageView = UIImageView()
        tempImageView.contentMode = .ScaleAspectFill
        return tempImageView
        
    }()
    
    var message: Message?{
        didSet{
            if message?.fromId == myAccount{
                self.subtitleLabel.text = "Me:"
                self.subtitleLabel.textColor = UIColor.redColor()
            } else {
                let uid = message?.fromId
                let ref = FIRDatabase.database().reference().child("users").child(uid!)
                ref.observeSingleEventOfType(.Value, withBlock: { (snapshot) in
                    let dictionary =  snapshot.value as! [String:AnyObject]
                    self.subtitleLabel.text = dictionary["name"] as? String
                    }, withCancelBlock: nil)
                self.subtitleLabel.textColor = UIColor.blueColor()
                 //print("myAcc:\(myAccount),other:\()")
                
            }
           
            
            self.setUpComponent()
        }
    }
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .Subtitle,reuseIdentifier:reuseIdentifier)
        currentIndex = 0
    }
    
    
    func setUpComponent(){
        
        subtitleLabel.frame = CGRectMake(5,5,200,20)
        detailLabel.frame = CGRectMake(5,30,350,20)
        
        detailLabel.font = UIFont(name:"arial", size:16)
        backgroundColor = UIColor.whiteColor()
        
        self.addSubview(subtitleLabel)
        self.addSubview(detailLabel)
        
        
        timestampLabel.frame = CGRectMake(self.frame.width - 150, 5,175,40)
        timestampLabel.textColor = UIColor.lightGrayColor()
        timestampLabel.font = UIFont.systemFontOfSize(12)
        print("\(self.currentIndex):\(self.frame.origin.y)")
        self.addSubview(timestampLabel)
        
        if let imageURLmessage = message?.imageURL{
            
            if let imageWidth = message?.imageWidth{
                
                if imageWidth.doubleValue > 150{
                    let newHeight = 150 * (message?.imageHeight)!.doubleValue / imageWidth.doubleValue
                    self.messagePhoto.frame = CGRectMake(0,0,150,CGFloat(newHeight))
                    //print("imageH:\(newHeight)")
                } else {
                    
                    self.messagePhoto.frame = CGRectMake(0,0,CGFloat(imageWidth),CGFloat((message?.imageHeight)!))
                }
                
                self.messagePhoto.userInteractionEnabled = true
            }
            
            self.messagePhoto.loadImageUsingCacheWithUrlString(imageURLmessage)
            self.messagePhoto.frame.origin.x = 5
            self.messagePhoto.frame.origin.y = self.subtitleLabel.frame.height + 10
            
            
            self.frame.size.height += self.messagePhoto.frame.height
            self.addSubview(self.messagePhoto)
        } else {
            
            self.frame.size.height = 60
            self.detailLabel.text = message?.text
        }
        
        
        if let seconds = message?.timestamp?.doubleValue {
            let timestamp = NSDate(timeIntervalSince1970: seconds)
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "YYYY/MM/dd/hh:mm a"
            self.timestampLabel.text = dateFormatter.stringFromDate(timestamp)
        }
  
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}