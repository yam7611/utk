//
//  User.swift
//  LoginTest
//
//  Created by yam7611 on 9/30/16.
//  Copyright © 2016 yam7611. All rights reserved.
//

import UIKit


class User:NSObject{
    
    var name : String?
    var username: String?
    var uid : String?
 
}
