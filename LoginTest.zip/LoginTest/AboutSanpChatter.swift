//
//  AboutSanpChatter.swift
//  LoginTest
//
//  Created by yam7611 on 9/21/16.
//  Copyright © 2016 yam7611. All rights reserved.
//

import UIKit

class AboutSanpChatter: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func leaveAboutSC(sender: UIButton) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}
