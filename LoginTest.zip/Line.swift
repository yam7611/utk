//
//  Line.swift
//  LoginTest
//
//  Created by yam7611 on 9/8/16.
//  Copyright © 2016 yam7611. All rights reserved.
//

import UIKit

class Line {
    var start: CGPoint
    var end: CGPoint
    
    init(start _start:CGPoint,end _end:CGPoint){
        start = _start
        end = _end
    }
}